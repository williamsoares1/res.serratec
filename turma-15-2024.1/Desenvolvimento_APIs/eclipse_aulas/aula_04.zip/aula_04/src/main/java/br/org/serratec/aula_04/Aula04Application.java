package br.org.serratec.aula_04;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aula04Application {

	public static void main(String[] args) {
		SpringApplication.run(Aula04Application.class, args);
	}

}
