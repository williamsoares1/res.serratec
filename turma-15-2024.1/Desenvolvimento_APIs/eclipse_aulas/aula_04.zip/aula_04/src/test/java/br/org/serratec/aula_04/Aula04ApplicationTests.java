package br.org.serratec.aula_04;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula04ApplicationTests {

	@Test
	void contextLoads() {
	}

}
