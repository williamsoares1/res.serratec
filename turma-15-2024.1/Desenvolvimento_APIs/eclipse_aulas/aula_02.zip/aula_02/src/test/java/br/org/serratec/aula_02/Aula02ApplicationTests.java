package br.org.serratec.aula_02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
